//
//  BaseViewModel.swift
//  Example
//
//  Created by Ilya Belenkiy on 11/21/25.
//

import Foundation
import Combine
import CombineEx
import AsyncNavigation

class BaseViewModel<T>: BasicViewModel {
   typealias PublishedValue = T

   let id: UUID = .init()

   var isCancelled = false
   var hasRequest = false
   var publishedValue: PassthroughSubject<T, Cancel> = .init()
   var children: [String : any AsyncNavigation.BasicViewModel] = [:]

   func publish(_ value: T) {
      _publish(value)
   }

   func cancel() {
      isCancelled = true
      _cancel()
   }
}
